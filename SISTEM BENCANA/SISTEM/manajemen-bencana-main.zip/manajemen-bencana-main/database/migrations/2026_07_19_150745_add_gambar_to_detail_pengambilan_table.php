<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::table('detail_pengambilan', function (Blueprint $table) {
            $table->string('gambar')->nullable()->after('keterangan');
        });
    }

    public function down(): void
    {
        Schema::table('detail_pengambilan', function (Blueprint $table) {
            $table->dropColumn('gambar');
        });
    }
};