<?php

namespace App\Http\Controllers;

use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;
use Spatie\Permission\Traits\HasRoles;
use Spatie\Permission\Models\Role;
use Illuminate\Support\Facades\Storage;

class UserController extends Controller
{
    use HasRoles;
    /**
     * Display a listing of the resource.
     */
    public function index(Request $request)
    {
        $query = User::with('roles');

        // Filter role DULU (sebelum search)
        if ($request->filled('role')) {
            $query->whereHas('roles', function ($q) use ($request) {
                $q->where('name', $request->role);
            });
        }

        // Search SETELAH filter role
        if ($request->has('search')) {
            $search = $request->search;
            $query->where(function ($q) use ($search) {
                $q->where('nama', 'like', "%{$search}%")
                    ->orWhere('email', 'like', "%{$search}%");
            });
        }

        $roles = Role::where('name', '!=', 'admin')->get();
        $users = $query->paginate(10)->appends($request->query());

        return view('management_user.index', compact('users', 'roles'));
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        $roles = Role::all();
        return view('management_user.create', compact('roles'));
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        $validated = $request->validate([
            'nama' => ['required', 'string', 'max:255'],
            'email' => ['required', 'string', 'lowercase', 'email', 'max:255', 'unique:user'],
            'password' => ['required', 'string', 'min:8', 'confirmed'],
            'nik' => ['nullable', 'string', 'max:16', 'unique:user'],
            'no_wa' => ['nullable', 'string', 'max:15'],
            'alamat' => ['nullable', 'string'],
            'deskripsi' => ['nullable', 'string', 'max:500'],
            'foto' => ['nullable', 'image', 'mimes:jpeg,png,jpg', 'max:2048'],
            'status' => ['required', 'in:aktif,nonaktif'],
            'role' => ['required', 'exists:roles,name'],
        ]);

        $fotoPath = null;
        if ($request->hasFile('foto')) {
            $fotoPath = $request->file('foto')->store('users', 'public');
        }

        $user = User::create([
            'nama' => $validated['nama'],
            'email' => $validated['email'],
            'password' => Hash::make($validated['password']),
            'nik' => $validated['nik'] ?? null,
            'no_wa' => $validated['no_wa'] ?? null,
            'alamat' => $validated['alamat'] ?? null,
            'deskripsi' => $validated['deskripsi'] ?? null,
            'foto' => $fotoPath,
            'status' => $validated['status'],
        ]);

        $user->assignRole($validated['role']);

        return redirect()->route('admin.management_user.index')->with('success', 'User berhasil ditambahkan');
    }

    /**
     * Display the specified resource.
     */
    public function show(User $user)
    {
        return view('management_user.show', compact('user'));
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(User $user)
    {
        // Cegah edit user dengan role admin
        if ($user->hasRole('admin')) {
            return redirect()->route('admin.management_user.index')
                ->with('error', 'Anda tidak dapat mengedit user admin');
        }

        $roles = Role::all();
        $userRole = $user->roles->first();

        return view('management_user.edit', compact('user', 'roles', 'userRole'));
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, User $user)
    {
        $validated = $request->validate([
            'nama' => ['required', 'string', 'max:255'],
            'email' => ['required', 'string', 'lowercase', 'email', 'max:255', 'unique:user,email,' . $user->id],
            'nik' => ['nullable', 'string', 'max:16', 'unique:user,nik,' . $user->id],
            'no_wa' => ['nullable', 'string', 'max:15'],
            'alamat' => ['nullable', 'string'],
            'deskripsi' => ['nullable', 'string'],
            'foto' => ['nullable', 'image', 'mimes:jpeg,png,jpg', 'max:2048'], // ← Tambah ini
            'status' => ['required', 'in:aktif,nonaktif'],
            'role' => ['required', 'exists:roles,name'],
            'password' => ['nullable', 'string', 'min:8', 'confirmed'],
        ]);

        // Handle upload foto
        $fotoPath = $user->foto; // Tetap foto lama jika tidak ada upload baru
        if ($request->hasFile('foto')) {
            // Hapus foto lama jika ada
            if ($user->foto && Storage::disk('public')->exists($user->foto)) {
                Storage::disk('public')->delete($user->foto);
            }
            // Upload foto baru
            $fotoPath = $request->file('foto')->store('users', 'public');
        }

        $user->update([
            'nama' => $validated['nama'],
            'email' => $validated['email'],
            'nik' => $validated['nik'] ?? null,
            'no_wa' => $validated['no_wa'] ?? null,
            'alamat' => $validated['alamat'] ?? null,
            'foto' => $fotoPath, // ← Tambah ini
            'status' => $validated['status'],
            'deskripsi' => $validated['deskripsi'] ?? null,
        ]);

        if ($validated['password'] ?? null) {
            $user->update(['password' => Hash::make($validated['password'])]);
        }

        $user->syncRoles($validated['role']);

        return redirect()->route('admin.management_user.index')->with('success', 'User berhasil diperbarui');
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(User $user)
    {
        if ($user->hasRole('admin')) {
            return redirect()->route('admin.management_user.index')
                ->with('error', 'Anda tidak dapat menghapus user admin');
        }

        $user->delete();
        return redirect()->route('admin.management_user.index')
            ->with('success', 'User berhasil dihapus');
    }
}
